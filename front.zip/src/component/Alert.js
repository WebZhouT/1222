import React, { Component } from 'react';
import { Toast,ToastHeader,ToastBody } from 'react-router-dom';

class Alert extends Component {

    state = {
        isOpen: false,
        title: '',
        content: '',
        icon: ''
    }

    render() {
        const {isOpen, title, content, icon} = this.state
        return (
            <div>
                <Toast isOpen={isOpen}>
                    <ToastHeader icon={icon}>
                    {title}
                    </ToastHeader>
                    <ToastBody>
                    {content}
                    </ToastBody>
                </Toast>
            </div>
        );
    }
}

export default Alert;