import Global from '../Global';
//解析json
function parseJSON(response){
    return response.json()
}

//检查请求状态
function checkStatus(response){
    if(response.status >= 200 && response.status < 500){
        return response
    }
    const error = new Error(response.statusText)
    error.response = response
    throw error
}

function request(options = {}){
    // console.log(options)
    const {data, url} = options
    // console.log(data)
    options = {...options}
    options.mode = 'cors'//跨域
    delete options.url
    if(data){
        delete options.data
        options.body = JSON.stringify(data)
    }
    options.headers={
        'Content-Type':'application/json'
    }
    return fetch(Global.API + url, options, {credentials: 'include'})
    .then(checkStatus)
    .then(parseJSON)
    .catch(err=>({err}))
}

function get(url){
    return request({url: url, method:'get'})
}

function post(url, data){
    return request({url: url, data: data, method:'post'})
}
  
export default {
    get,
    post
}