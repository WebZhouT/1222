import React, { Component } from 'react';
import { Button, Container,Input,Row,Col,Form,FormGroup,Card,CardBody,ModalBody,Modal,ModalHeader } from 'reactstrap';
import { withRouter } from 'react-router-dom'
import { Link } from 'react-router-dom';
import logo from '../logo.svg'
import request from '../util/request'
class Search extends Component {

  state = {
    isLogin: false,
    keyword: '',
    logined: false,
    user: {
      _id: '',
      username: '',
      password: ''
    },
    form: {
      username: '',
      password: ''
    }
  }

  constructor(props) {
    super(props);
    this.handleChange = this.handleChange.bind(this);
  }

  componentDidMount() {
    if(this.props.location.query != undefined){
      this.setState({keyword: this.props.location.query.keyword});
    }
    const reactUser = localStorage.getItem("reactUser")
    if(reactUser != undefined && reactUser != null){
      this.setState({logined: true, user: JSON.parse(reactUser)});
    }
  }

  showLogin = (sign) => {
    this.setState({
      isLogin: sign, 
      form: {
        username: '',
        password: ''
      }
    });
  }

  search = () => {
    let keyword = this.state.keyword;
    // console.log(keyword);
    // console.log(this.props.location.pathname)
    if(this.props.location.pathname == '/music'){
      this.props.ListMusic(keyword);
    }else{
      // console.log(this.props.history)
      // this.setState({keyword: ''});
      this.props.history.push({pathname:'/music', query:{keyword:keyword}})
    }
  }

  toCart = () => {
    if(!this.state.logined){
      alert("please to login")
      return
    }
    this.props.history.push({pathname:'/cart'})
  }

  logout = () => {
    localStorage.removeItem('reactUser');
    this.setState({
      form: {
        username: '',
        password: ''
      },
      isLogin: false,
      logined: false,
      user:  {
        _id: '',
        username: '',
        password: ''
      }
    })
  }

  login = () => {
    let form = {...this.state.form};
    // console.log(form);
    request.post(`api/login`, form).then((res) => {
      // console.log(res);
      if(res.code == 200){
        this.setState({
          form: {
            username: '',
            password: ''
          },
          isLogin: false,
          logined: true,
          user: res.data
        })
        localStorage.setItem("reactUser", JSON.stringify(res.data))
        alert('login success');
      }else{
        alert(res.msg);
      }
    }).catch(err => {
      // console.log(err)
    });
  }

  reg = () => {
    let form = {...this.state.form};
    // console.log(form);
    request.post(`api/reg`, form).then((res) => {
      // console.log(res);
      if(res.code == 200){
        this.setState({
          form: {
            username: '',
            password: ''
          },
          isLogin: false
        })
        alert('register success');
      }else{
        alert(res.msg);
      }
    }).catch(err => {
      // console.log(err)
    });
  }

  handleSearch = (event) => {
    const target = event.target;
    // console.log('keyword:' + target.value)
    this.setState({keyword: target.value});
  }

  handleChange(event) {
    const target = event.target;
    const value = target.value;
    const name = target.name;
    let item = {...this.state.form};
    item[name] = value
    this.setState({
      form: item
    });
  }
 
  render() {
    const {isLogin, form, keyword, logined, user} = this.state
    return (
      <div>
        <Container fluid>
          <Row xs="4">
            <Col tag={Link} to={"/"}>
                <img src={logo} style={{width:"40px", height:"40px", textAlign:"center"}} />
            </Col>
            <Col xs="6">
              <Input placeholder="keyword" defaultValue={keyword} onChange={this.handleSearch}></Input>
            </Col>
            <Col>
              <Button color="info" onClick={this.search}>Search</Button>
            </Col> 
            <Col></Col>
          </Row>
          <br/>
          <Row xs="4">
            <Col xs="9"></Col>
            {
              logined ? (
                <Col xs="1"><span style={{cursor:'pointer'}}>{user.username}</span></Col>
              ) : (
                <Col xs="1"><span style={{cursor:'pointer'}} onClick={() => this.showLogin(true)}>Sign In</span></Col>
              )
            }
            {
              logined ? (
                <Col xs="1"><span style={{cursor:'pointer'}} onClick={() => this.logout()}>Logout</span></Col>
              ) : (
                <Col xs="1"><span style={{cursor:'pointer'}} onClick={() => this.showLogin(true)}>Register</span></Col>
              )
            }
            <Col xs="1">
              <Button color="info" onClick={this.toCart}>Cart</Button>
            </Col> 
          </Row>
          <Modal isOpen={isLogin}>
            <ModalHeader toggle={() => this.showLogin(false)}>
              Login/Register
            </ModalHeader>
            <ModalBody>
              <Row>
                {/* <Col md={1}></Col> */}
                <Col md={12}>
                  <Card outline>
                    <CardBody>
                    <Form>
                      <FormGroup>
                        <Input
                          id="username"
                          name="username"
                          placeholder="Username"
                          defaultValue={form.username}
                          onChange={this.handleChange}
                          ref="txt"
                        />
                      </FormGroup>
                      <FormGroup>
                        <Input
                          id="password"
                          name="password"
                          placeholder="Password"
                          type="password"
                          defaultValue={form.password}
                          onChange={this.handleChange}
                          ref="txt"
                        />
                      </FormGroup>
                      <Row>
                        <Col md={3}>
                          <Button color="danger" onClick={this.login}>SUBMIT</Button>
                        </Col> 
                        <Col md={3}>
                          <Button color="danger" onClick={this.reg}>CREATE</Button>
                        </Col>
                      </Row>
                    </Form>
                    </CardBody>
                  </Card>
                </Col>
                {/* <Col md={1}></Col> */}
              </Row>
            </ModalBody>
          </Modal>
          <br/>
        </Container>
      </div>
    );
  }
}

export default withRouter(Search)