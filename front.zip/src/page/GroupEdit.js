import React, { Component } from 'react';
import { Link, withRouter } from 'react-router-dom';
import { Button, Container, Form, FormGroup, Input, Label} from 'reactstrap';
import AppNavbar from './AppNavbar';
import Global from '../Global';
 
class GroupEdit extends Component {
 
  emptyItem = {
    _id: '',
    lastName: '',
    firstName: '',
    sex: '',
    age: '',
    password: ''
  };
 
  constructor(props) {
    super(props);
    this.state = {
      item: this.emptyItem,
      visible: false,
      error: ''
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }
 
  async componentDidMount() {
    if (this.props.match.params.id !== 'new') {
      const res = await (await fetch(Global.API  + `api/user/${this.props.match.params.id}`)).json();
      let item = {
        _id: res.data._id,
        lastName: res.data.last_name,
        firstName: res.data.first_name,
        sex: res.data.sex,
        age: res.data.age,
        password: res.data.password,
        repeat: ''
      }
      this.setState({item: item});
    }
  }
 
  handleChange(event) {
    const target = event.target;
    const value = target.value;
    const name = target.name;
    let item = {...this.state.item};
    item[name] = value;
    this.setState({item});
  }
 
  async handleSubmit(event) {
    event.preventDefault();
    const {item} = this.state;
    let api = Global.API + 'api/user/add';
    let that = this;
    console.log(item);
    if(item.password === ""){
        setTimeout(function(){
          that.setState({error: '密码不能为空'});
        }, 100)
        return;
    }
    if(item.password !== item.repeat){
      setTimeout(function(){
        that.setState({error: '密码不一致'});
      }, 100)
      return;
    }
    // console.log(item);
    if(item._id !== null && item._id !== undefined && item._id !== ""){
        api = Global.API + 'api/user/update'
    }
    await fetch(api, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      mode: "cors",
      body: JSON.stringify(item),
    });
    this.props.history.push('/groups');
  }
 
  render() {
    const {item, error} = this.state;
    const title = <h2>{item.id ? 'Edit Group' : 'Add Group'}</h2>;
 
    return <div>
      <AppNavbar/>
      <Container>
        {title}  <span style={{color:'red'}}>{error}</span>
        <Form onSubmit={this.handleSubmit}>
          <FormGroup>
            <Label for="firstName">FirstName</Label>
            <Input type="text" name="firstName" id="firstName" value={item.firstName || ''}
                   onChange={this.handleChange} autoComplete="firstName"/>
          </FormGroup>
          <FormGroup>
            <Label for="lastName">LastName</Label>
            <Input type="text" name="lastName" id="lastName" value={item.lastName || ''}
                   onChange={this.handleChange} autoComplete="address-level1"/>
          </FormGroup>
          <FormGroup>
            <Label for="age">Age</Label>
            <Input type="number" name="age" id="age" value={item.age || ''}
                   onChange={this.handleChange} autoComplete="age"/>
          </FormGroup>
          <FormGroup>
            <Label for="sex">Sex</Label>
            <Input type="select" name="sex" id="sex" onChange={this.handleChange} autoComplete="age" value={item.sex || ''} >
              <option value="2">male</option>
              <option value="1">man</option>
            </Input>
          </FormGroup>
          <FormGroup>
            <Label for="password">Password</Label>
            <Input type="password" name="password" id="password" value={item.password || ''}
                   onChange={this.handleChange} autoComplete="password"/>
          </FormGroup>
          <FormGroup>
            <Label for="repeat">Repeat</Label>
            <Input type="password" name="repeat" id="repeat" 
                   onChange={this.handleChange} autoComplete="repeat"/>
          </FormGroup>
          <FormGroup>
            <Button color="primary" type="submit">Save</Button>{' '}
            <Button color="secondary" tag={Link} to="/groups">Cancel</Button>
          </FormGroup>
        </Form>
      </Container>
    </div>
  }
}
 
export default withRouter(GroupEdit);