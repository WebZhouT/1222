import React, { Component } from 'react';
import { Container,Row,Col } from 'reactstrap';
import { Link } from 'react-router-dom';
import Search from './Search';
import './MusicList.css'
import request from '../util/request'

export default class MusicList extends Component {

  state = {
    category: '',
    musicList: [
      
    ]
  }
  
  constructor(props) {
    super(props);
    // this.listMusic = this.listMusic.bind(this);
  }

  componentDidMount() {
    // if(this.props.location.query != undefined){
    //   console.log(this.props.location.query)
    // }
    let keyword = ''
    if(this.props.location.query != undefined){
      keyword = this.props.location.query.keyword
    }
    this.listMusic(keyword);
  }

  listMusic = (keyword) => {
    // console.log(keyword)
    let data = {category: this.state.category, keyword: ''}
    if(keyword != undefined){
      data.keyword = keyword;
    }
    request.post(`api/music/list`, data).then((res) => {
      // console.log(res);
      this.setState({musicList: res.data});
    }).catch(err => {
      // console.log(err)
    });
  }
 
  setCategory = (category) => {
    // console.log(123)
    // console.log(category)
    this.setState({category: category}, () => {
      this.listMusic()
    });
  }

  render() {
    let pStyle = {cursor:'pointer', textDecoration:"underline"}
    const {musicList, category} = this.state
    return (
      <div>
        <Search ListMusic={this.listMusic}></Search>
        <Container fluid>
          <Row style={{"borderTop":"3px solid black"}}>
            <Col xs={2} style={{"borderRight":"3px solid black", "width": '200px', "position":"absolute", "bottom": '0px', "top": "180px"}}>

              <h3 style={{cursor:'pointer'}} onClick={() => this.setCategory('')}>Category</h3>
              <ul style={{listStyle:'none'}}>
                <li>
                  <p style={pStyle} onClick={() => this.setCategory('Classic')}>Classic</p>
                </li>
                <li>
                  <p style={pStyle} onClick={() => this.setCategory('Baroque')}>Baroque</p>
                </li>
                <li>
                  <p style={pStyle} onClick={() => this.setCategory('Romantic')}>Romantic</p>
                </li>
                <li>
                  <p style={pStyle} onClick={() => this.setCategory('Late 19th')}>Late 19th</p>
                </li>
              </ul>
            </Col>
            <Col xs={10} style={{"marginLeft":"210px"}}>
              <Row>
                <p>Home>Music</p>
              </Row>
              <Row>
                <h5>Search Result</h5>
              </Row>
              <Row>
                {
                  musicList.map((music, index) => 
                    <div className="photo" key={index}>
                      <div className="photo_title">
                          <Link to={"/info/" + music._id}>
                            <span>{music.musicName}</span>
                          </Link>
                      </div>
                      <div>
                          <a  target="_blank">
                              <img  src={music.img} alt="" className="photo_img"/>
                          </a>
                      </div>
                    </div>
                  )
                }
              </Row>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
}