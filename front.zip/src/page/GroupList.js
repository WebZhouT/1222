import React, { Component } from 'react';
import { Button, ButtonGroup, Container, Table, Input } from 'reactstrap';
import AppNavbar from './AppNavbar';
import Global from '../Global';
import { Link } from 'react-router-dom';
import { userList, userStart} from "../store/action";
import PropTypes from 'prop-types'
import { connect } from "react-redux";
 
class GroupList extends Component {
 
  constructor(props) {
    super(props);
    // console.log(props.userList({key: 123}));
    // console.log(props.userData);
    this.state = {
      groups: [], 
      isLoading: true,
      keyword: '',
      pageSize: 10,
      pageNum: 1,
      total: 0,
      sort: '^',
      sortParam: {

      }
    };
    this.remove = this.remove.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.pageList = this.pageList.bind(this);
    this.search = this.search.bind(this);
    this.pre = this.pre.bind(this);
    this.next = this.next.bind(this);
    this.sortFirst = this.sortFirst.bind(this);
  }
 
  componentDidMount() {
    this.setState({isLoading: true});
    this.pageList();
  }

  pageList(){
    const {keyword, pageNum, pageSize, sortParam} = this.state;
    let query = {
      keyword: keyword,
      pageNum: pageNum,
      pageSize: pageSize,
      sort: sortParam
    }
    this.props.userList(query);
    // console.log(this.props.pageData);
    // fetch(Global.API + 'api/user/page/list', {
    //   method: 'POST',
    //   mode: "cors",
    //   headers: {
    //     'Accept': 'application/json',
    //     'Content-Type': 'application/json'
    //   },
    //   body: JSON.stringify(query),
    // })
    // .then(response => response.json())
    // .then(res => {
    //   //   console.log(data);
    //   this.setState({groups: res.data.data, isLoading: false, total: res.data.total})
    // });
  }

  handleChange(event) {
    const target = event.target;
    const value = target.value;
    this.setState({keyword: value})
  }

  sortFirst(){
    const {sort} = this.state;
    let that = this;
    if(sort === "^"){
      setTimeout(function(){
        that.setState({sort: "v", sortParam: {'first_name': 1}});
        that.pageList();
      }, 100);
    }else{
      setTimeout(function(){
        that.setState({sort: "^", sortParam: {'first_name': -1}});
        that.pageList();
      }, 100);
    }
  }

  search(){
    this.pageList();
  }

  pre(){
    const {pageNum} = this.state;
    let that = this;
    if(pageNum > 1){
      // console.log(pageNum);
      setTimeout(function(){
        that.setState({pageNum : pageNum - 1});
        that.pageList();
      }, 100);
    }
  }

  next(){
    const {pageNum} = this.state;
    let that = this;
    setTimeout(function(){
      that.setState({pageNum : pageNum + 1});
      that.pageList();
    }, 100);
  }
 
  async remove(id) {
    await fetch(Global.API + `api/user/${id}`, {
      method: 'DELETE',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      }
    }).then(() => {
      let updatedGroups = [...this.state.groups].filter(i => i._id !== id);
      this.setState({groups: updatedGroups});
    });
  }
 
  render() {
    const {groups, isLoading,pageNum,sort} = this.state;
    const {isFetching, userData} = this.props
 
    if (!isFetching) {
      return <p>Loading...</p>;
    }
    // console.log(userData);
    const groups2 = userData.data.data;
    // const groupList = [];
    const groupList = groups2.map(group => {
      // console.log(group);
      let id = group._id;
      return <tr key={id}>
        <td>{group.first_name}</td>
        <td style={{whiteSpace: 'nowrap'}}>{group.last_name}</td>
        <td>{group.sex === 1 ? "man" : "male"}</td>
        <td>{group.age}</td>
        <td>
          <ButtonGroup>
            <Button size="sm" color="primary" tag={Link} to={"/groups/" + id}>Edit</Button>
            <Button size="sm" color="danger" onClick={() => this.remove(id)}>Delete</Button>
          </ButtonGroup>
        </td>
      </tr>
    });
 
    return (
      <div>
        <AppNavbar/>
        <Container fluid>
          <h3>用户列表</h3>
          <div className="row">
            <div className="col-md-4">
              <Input type="text" name="keyword" id="keyword" 
                    onChange={this.handleChange} autoComplete="keyword"/>
            </div>
            <div className="col-md-4">
              <Button color="success" onClick={this.search}>Search</Button>
            </div>
            <div className="col-md-4">
              <Button color="success" tag={Link} to="/groups/new">Add Group</Button>
            </div>
          </div>
          <Table className="mt-4">
            <thead>
            <tr>
              <th width="20%" onClick={this.sortFirst}>FirstName {sort}</th>
              <th width="20%">Last Name</th>
              <th>Sex</th>
              <th>Age</th>
              <th width="10%">Actions</th>
            </tr>
            </thead>
            <tbody>
            {groupList}
            </tbody>
          </Table>
          <div className="row">
            <div className="col-md-1">
              <Button color="info" onClick={this.pre} disabled={pageNum === 1}>Pre</Button>
            </div>
            <Button color="info" onClick={this.next}>Next</Button>
          </div>
        </Container>
      </div>
    );
  }
}
 
GroupList.propTypes = {
  isFetching: PropTypes.bool.isRequired,
  userData: PropTypes.object.isRequired,
  userList: PropTypes.func.isRequired
}

// Map Redux state to component props
function mapStateToProps(state) {
  // console.log(state.user);
  return {
    isFetching: state.user.isFetching,
    userData: state.user.pageData
  }
}

// Map Redux actions to component props
function mapDispatchToProps(dispatch) {
  return {
    userList: (param) => {
      dispatch(userStart);
      fetch(Global.API + 'api/user/page/list', {
        method: 'POST',
        mode: "cors",
        headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
        },
        body: JSON.stringify(param),
      })
      .then(response => response.json())
      .then(res => {
        dispatch(userList(res))
      });
    }
  }
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(GroupList)