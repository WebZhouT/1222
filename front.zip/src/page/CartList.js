import React, { Component } from 'react';
import { Container,Row,Col,Input,Button } from 'reactstrap';
import { Link } from 'react-router-dom';
import Search from './Search';
import request from '../util/request'
export default class CartList extends Component {

  state = {
    cartList: [],
    total: 0,
    logined: false,
    user: {
      _id: '',
      username: '',
      password: ''
    },
  }
  
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    // console.log(this.props.match)
    const reactUser = localStorage.getItem("reactUser")
    if(reactUser != undefined && reactUser != null){
      this.setState({logined: true, user: JSON.parse(reactUser)});
    }
    this.listCart();
  }

  listCart = () => {
    request.post('api/cart/list', {username: this.state.user.username}).then(res => {
      // console.log(res)
      var s = 0;
      res.data.forEach(function(val, idx, arr) {
          s += val.musicId.price * val.quantity;
      }, 0);
      this.setState({cartList: res.data, total: s});
    })
  }

  delCart = (id) => {
    if(!this.state.logined){
      alert("please to login")
      return;
    }
    request.post('api/cart/delete', {musicId: id, 
        username: this.state.user.username
      }).then(res => {
      if(res.code == 200){
        alert("delete cart success")
        this.listCart();
      }else{
        alert(res.msg)
      }
    })
  }

  checkout = () => {
    if(!this.state.logined){
      alert("please to login")
      return
    }
    this.props.history.push({pathname:'/checkout'})
  }

  render() {
    let pStyle = {cursor:'pointer', textDecoration:"underline"}
    const {cartList, total} = this.state
    return (
      <div>
        <Search></Search>
        <Container fluid>
          <Row>
            <Col md={1}></Col>
            <Col md={10}>
              <Row>
                <h3>My Shopping Cart</h3>
              </Row>
              <br/>

                {
                  cartList.map((cart, index) => 
                    <Row key={index} style={{"borderBottom": "3px solid red", "display":"block", "padding":"30px"}}>
                      <div>
                        <h5>Music Name:{cart.musicId.musicName}</h5>
                      </div>
                      <div>
                        <h5>Quantity:{cart.quantity}</h5>
                      </div>
                      <div>
                        <Button color="danger" onClick={() => this.delCart(cart.musicId._id)}>delete</Button>
                      </div>
                    </Row>
                  )
                }

              <Row>Total Price: $ {
                total
              }</Row>
              <Row><Button color="info" onClick={this.checkout}>Check out</Button></Row>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
}