import React, { Component} from 'react';
import Search from './Search';
import PropTypes from 'prop-types'
import { connect } from "react-redux";
import { Link } from 'react-router-dom';
import { Container,Row,Col} from 'reactstrap';
import { countAdd, countReduce} from "../store/action";
import musicGif from '../assert/music.gif';
 
class Home extends Component {

  state = {
    isLogin: false,
  }

  constructor(props) {
    super(props);
    // props.onAddClick();
    console.log(props.count);
  }

  showLogin = () => {
    this.setState({isLogin: true});
  }

  render() {
    const { count, onAddClick, onReduceClick} = this.props
    return (
      <div color="grey">
        <Search></Search>
        <Container fluid>
          <Row>
            <Col md={12}>
              <img src={musicGif} alt="" style={{width:'100%'}} />
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
}

Home.propTypes = {
  count: PropTypes.number.isRequired,
  onAddClick: PropTypes.func.isRequired,
  onReduceClick: PropTypes.func.isRequired
}

// Map Redux state to component props
function mapStateToProps(state) {
  return {
    count: state.count.count
  }
}

// Map Redux actions to component props
function mapDispatchToProps(dispatch) {
  return {
    onAddClick: () => {
      // console.log("dispatch");
      dispatch(countAdd)
    },
    onReduceClick: () => {
      // console.log("dispatch");
      dispatch(countReduce)
    },
  }
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Home)

// export default Home;
