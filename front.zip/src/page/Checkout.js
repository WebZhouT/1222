import React, { Component } from 'react';
import { Container,Row,Col,Input,Button,Form,FormGroup,Label,FormText } from 'reactstrap';
import { Link } from 'react-router-dom';
import Search from './Search';
import request from '../util/request'
export default class Checkout extends Component {

  state = {
    cartList: [],
    total: 0,
    logined: false,
    ok: false,
    user: {
      _id: '',
      username: '',
      password: ''
    },
    form: {
      fullname: '',
      companyName: '',
      addressLine: '',
      addressLine2: '',
      city: '',
      region: '',
      country: '',
      zipCode: '',
    }
  }
  
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    // console.log(this.props.match)
    const reactUser = localStorage.getItem("reactUser")
    if(reactUser != undefined && reactUser != null){
      this.setState({logined: true, user: JSON.parse(reactUser)});
    }
    this.listCart();
  }

  listCart = () => {
    request.post('api/cart/list', {username: this.state.user.username}).then(res => {
      // console.log(res)
      var s = 0;
      res.data.forEach(function(val, idx, arr) {
          s += val.musicId.price * val.quantity;
      }, 0);
      this.setState({cartList: res.data, total: s});
    })
  }

  delCart = (id) => {
    if(!this.state.logined){
      alert("please to login")
      return;
    }
    request.post('api/cart/delete', {musicId: id, 
        username: this.state.user.username
      }).then(res => {
      if(res.code == 200){
        alert("delete cart success")
        this.listCart();
      }else{
        alert(res.msg)
      }
    })
  }

  handleChange = (event) => {
    const target = event.target;
    const value = target.value;
    const name = target.name;
    // console.log(name, value)
    let item = {...this.state.form};
    item[name] = value
    this.setState({
      form: item
    });
  }

  confirm = () => {
    if(!this.state.logined){
      alert("please to login")
      return;
    }
    // console.log(this.state.form)
    this.setState({ok: true})
  }

  render() {
    let pStyle = {cursor:'pointer', textDecoration:"underline"}
    const {form, total, ok} = this.state
    return (
      <div>
        <Search></Search>
        <Container fluid>
          <Row xs={12}>
            <Col md={1}></Col>
            {ok ? (
              <Col md={11}>
              <Row>
                <h3>Invoice page:</h3>
              </Row>
              <br/>

                <Row>
                  <h5>Full Name:</h5> {form.fullname}
                </Row>
                <Row>
                  <h5>Company:</h5> {form.company}
                </Row>
                <Row>
                  <h5>Address Line 1:</h5> {form.addressLine}
                </Row>
                <Row>
                  <h5>Address Line 2:</h5> {form.addressLine2}
                </Row>
                <Row>
                  <h5>Region:</h5> {form.region}
                </Row>
                <Row>
                  <h5>City:</h5> {form.city}
                </Row>
                <Row>
                  <h5>Country:</h5> {form.country}
                </Row>
                <Row>
                  <h5>Postcode:</h5> {form.zipCode}
                </Row>

              <br/>
              <Row><h5>Total Price: $ {total}</h5></Row>
              <Row style={{"borderBottom": "3px solid red", "display":"block", "padding":"3px"}}></Row>
              <Row><h5>Thank you for your order, You will must be delivered within 7 working days</h5></Row>
              <Row><Link to="/music"><Button color="info">ok</Button></Link></Row>
            </Col>
            ) : (
              <Col md={11}>
              <Row>
                <h3>Delivery Address:</h3>
              </Row>
              <br/>
              <Row md={12}>
              <Form>
                <FormGroup row>
                  <Label sm={4}>Full Name</Label>
                  <Col sm={8}>
                    <Input
                      id="fullname"
                      name="fullname"
                      placeholder=""
                      type="text"
                      // defaultValue={form.fullname}
                      onChange={this.handleChange}
                    />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label sm={4}>Company</Label>
                  <Col sm={8}>
                    <Input
                      id="companyName"
                      name="companyName"
                      placeholder=""
                      type="text"
                      onChange={this.handleChange}
                    />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label sm={4}>Address Line 1</Label>
                  <Col sm={8}>
                    <Input
                      id="addressLine"
                      name="addressLine"
                      placeholder=""
                      type="text"
                      onChange={this.handleChange}
                    />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label sm={4}>Address Line 2</Label>
                  <Col sm={8}>
                    <Input
                      id="addressLine2"
                      name="addressLine2"
                      placeholder=""
                      type="text"
                      onChange={this.handleChange}
                    />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label sm={4}>City</Label>
                  <Col sm={8}>
                    <Input
                      id="city"
                      name="city"
                      placeholder=""
                      type="text"
                      onChange={this.handleChange}
                    />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label sm={4}>Region/State</Label>
                  <Col sm={8}>
                    <Input
                      id="region"
                      name="region"
                      placeholder=""
                      type="text"
                      onChange={this.handleChange}
                    />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label sm={4}>Country</Label>
                  <Col sm={8}>
                    <Input
                      id="country"
                      name="country"
                      placeholder=""
                      type="text"
                      onChange={this.handleChange}
                    />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label sm={4}>Postcode/Zip code</Label>
                  <Col sm={8}>
                    <Input
                      id="zipCode"
                      name="zipCode"
                      placeholder=""
                      type="text"
                      onChange={this.handleChange}
                    />
                  </Col>
                </FormGroup>
              </Form>
              </Row>
              <Row style={{"borderBottom": "3px solid red", "display":"block", "padding":"3px"}}></Row>
              <Row>Your order(<Link to="/cart">change</Link>)</Row>
              <Row>
                <h5>Free Standard shopping</h5>
              </Row>
              <Row><h5>Total Price: $ {total}</h5></Row>
              <Row><Button color="info" onClick={this.confirm}>Confirm</Button></Row>
            </Col>
            )}
          </Row>
        </Container>
      </div>
    );
  }
}