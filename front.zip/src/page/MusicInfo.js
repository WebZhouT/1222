import React, { Component } from 'react';
import { Container,Row,Col,Input,Button } from 'reactstrap';
import { Link } from 'react-router-dom';
import Search from './Search';
import request from '../util/request'
export default class MusicInfo extends Component {

  state = {
    category: '',
    quantity: 1,
    music: {
      id: '',
      musicName: 'Bach, J.S.: Concerto No. 1 in D Major',
      category: 'Baroque',
      composer: 'Bach',
      price: '140',
      img: 'http://localhost:9999/img_1.jpg',
      url: '',
      description: 'Baroque music, a style of music that prevailed during the period from about 1600 to about 1750',
      published: '1791',
      newArrival: ''
    }
  }
  
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    // console.log(this.props.match)
    this.infoMusic();
  }

  handleChange = (event) => {
    const target = event.target;
    // console.log(target.value)
    this.setState({quantity: target.value});
  }

  infoMusic = () => {
    request.get('api/music/' + this.props.match.params.id).then(res => {
      // console.log(res)
      this.setState({music: res.data});
    })
  }

  addCart = () => {
    const reactUser = localStorage.getItem("reactUser")
    if(reactUser == undefined || reactUser == null){
      alert("please to login")
      return;
    }
    const user = JSON.parse(reactUser);
    request.post('api/cart/add', {musicId: this.props.match.params.id, 
      username: user.username, 
      quantity: this.state.quantity}).then(res => {
      if(res.code == 200){
        alert("add cart success")
      }else{
        alert(res.msg)
      }
    })
  }

  render() {
    let pStyle = {cursor:'pointer', textDecoration:"underline"}
    const {music, quantity} = this.state
    return (
      <div>
        <Search></Search>
        <Container fluid>
          <Row>
            <Col md={1}>
            </Col>
            <Col>
              <Row>
                <h4>{music.musicName}</h4>
              </Row>
              <Row>
                <img  src={music.img} alt="" style={{width: '200px', height: '250px'}}/>
              </Row>
              <Row>
                <audio src={music.url} controls="controls"></audio>
              </Row>
              <Row>
                <h5>Composer:{music.composer}</h5>
              </Row>
              <Row>
                <h5>Published:{music.published}</h5>
              </Row>
              <Row>
                <h5>Category:{music.category}</h5>
              </Row>
              <Row>
                <h5>Description:{music.description}</h5>
              </Row>
              <Row>
                <h4>Price:$ {music.price}</h4>
              </Row>
              <br/>
              <Row>
                <Col md={1} style={{textAlign:"left"}}>
                  <h5>Order:</h5>
                </Col>
                <Col md={2} >
                  <Input type="number" defaultValue={quantity} onChange={this.handleChange}/>
                </Col>
                <Col md={1}>
                  <Button color="info" onClick={this.addCart}>Add to Cart</Button>
                </Col>
              </Row>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
}