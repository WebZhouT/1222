const Global = {
    API : "http://localhost:9999/"
}

export default Global