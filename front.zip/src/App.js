import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import './App.css';

import Home from './page/Home';
import MusicList from './page/MusicList';
import MusicInfo from './page/MusicInfo';
import CartList from './page/CartList';
import Checkout from './page/Checkout';

function App() {
  return (
    <Router>
      <Switch>
        <Route path='/' exact={true} component={Home}/>
        <Route path='/music' exact={true} component={MusicList}/>
        <Route path='/info/:id' component={MusicInfo}/>
        <Route path='/cart' exact={true} component={CartList}/>
        <Route path='/checkout' exact={true} component={Checkout}/>
      </Switch>
    </Router>
  );
}

export default App;
