import { combineReducers } from "redux";
import { COUNT_ADD, COUNT_REDUCE, USER_LIST, USER_START} from "./action-type";

const initCount = {
  count: 1,
};

function count(state = initCount, action) {
//   console.log(action.type);
  const count = state.count
  switch (action.type) {
    case COUNT_ADD:
      return { count: count + 1 };
    case COUNT_REDUCE:
      return { count: count - 1 };
    default:
      return state;
  }
}


function user(state = {isFetching: false, pageData: {}}, action) {
//   console.log(action.type);
    switch (action.type) {
    case USER_LIST:
        // console.log(action.param);
        return {isFetching: true, pageData: action.param};
    case USER_START:
    return {isFetching: false};
    default:
        return state;
    }
}





export default combineReducers({
  count,user
});