import { COUNT_ADD, COUNT_REDUCE, USER_LIST, USER_START} from "./action-type";

export const countAdd = { type: COUNT_ADD }

export const countReduce = { type: COUNT_REDUCE }

export const userList = (param) => ({type: USER_LIST, param})

export const userStart = () => ({type: USER_START})
    
