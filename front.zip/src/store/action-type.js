// count自增
export const COUNT_ADD = 'COUNT_ADD'
// count自减
export const COUNT_REDUCE = 'COUNT_REDUCE'

export const USER_LIST = 'USER_LIST'

export const USER_START = 'USER_START'