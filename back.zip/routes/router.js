let express = require('express');
let user = require('../controls/user');
let music = require('../controls/music');
let cart = require('../controls/cart');
let api = require('../api');
let upload = require('../utils/upload');


let router = express.Router();

// user
router.post(api.list, user.list);
router.post(api.pageList, user.pageList);
router.delete(api.delete, user.delete);
router.post(api.add, user.add);
router.post(api.update, user.update);
router.get(api.get, user.get);

router.post(api.login, user.login);
router.post(api.reg, user.reg);

router.post(api.music_list, music.list);
router.post(api.music_pageList, music.pageList);
router.get(api.music_get, music.get);

router.post(api.cart_add, cart.add);
router.post(api.cart_delete, cart.delete);
router.post(api.cart_list, cart.list);
router.post(api.cart_pageList, cart.pageList);

module.exports = router;