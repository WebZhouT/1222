let model = require('../sql/model');
let Cart = model.Cart

module.exports = {
    list (req, res) {
        let username = req.body.username;
        let query = {}
        if(username != "" && username != undefined){
            query = {
                username: username
            }
        }
        Cart.find(query).populate('musicId').exec((err,ret) => {
            if (!err) {
                // console.log(ret);
                res.json({code: 200, msg: 'done', data: ret});
                
            }else{
                // console.log(err);
                res.json({code: 500, msg: 'done'});    
            }
        });
    },

    pageList (req, res) {
        let username = req.body.username;
        let page = req.body.pageNum || 1;
        let limit = req.body.pageSize || 10;
        let query = {};
        if(username != "" && username != undefined){
            query = {
                username: username
            }
        }
        let total = 0;
        Cart.find(query).countDocuments().exec((err,ret) => {
            if (!err) {
                total = ret;
                let pageData = {
                    data: [],
                    total: total,
                    pageNum: page,
                    pageSize: limit
                };
                Cart.find(query).skip((page - 1)*parseInt(limit)).populate('musicId').limit(parseInt(limit)).exec((err1,ret1) => {
                    if (!err1) {
                        pageData.data = ret1
                        res.json({code: 200, msg: 'done', data: pageData});
                    }else{
                        // console.log(err1);
                        res.json({code: 500, msg: 'done'});    
                    }
                });
            }else{
                // console.log(err);
                res.json({code: 500, msg: 'done'});    
            }
        });
    },

    add (req, res) {
        const entity = new Cart({
            username: req.body.username,
            quantity: req.body.quantity,
            musicId: req.body.musicId
        });
        entity.save().then((ret) => {
            // console.log(ret);
            res.json({code: 200, msg: 'done'});
        });   
    },

    get (req, res) {
        Cart.findOne({
            _id: req.params.id,
        },(err,ret) => {
            if (!err) {
                console.log(ret);
                res.json({code: 200, msg: 'done', data: ret});
            }else{
                res.json({code: 500, msg: 'done'}); 
            }
        });
    },

    // 删除用户
    delete (req, res) {
        Cart.remove({
            username: req.body.username,
            musicId: req.body.musicId
        },(err,ret) => {
            if (!err) {
                console.log('delete sucess!');
                res.json({code: 200, msg: 'done'});
            }else{
                res.json({code: 500, msg: 'done'}); 
            }
        });
    }
};