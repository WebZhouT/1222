let model = require('../sql/model');
let User = model.User

module.exports = {
    list (req, res) {
        let keyword = req.body.keyword;
        let query = {}
        if(keyword != "" && keyword != undefined){
            query = {
                username: '/' + keyword + '/'
            }
        }
        User.find(query, (err,ret) => {
            if (!err) {
                console.log(ret);
                res.json({code: 200, msg: 'done', data: ret});
                
            }else{
                console.log(err);
                res.json({code: 500, msg: 'done'});    
            }
        });
    },

    pageList (req, res) {
        let keyword = req.body.keyword;
        let page = req.body.pageNum || 1;
        let limit = req.body.pageSize || 10;
        let sort = req.body.sort
        let query = {};
        if(keyword != "" && keyword != undefined){
            query = {
                username: '/' + keyword + '/'
            }
        }
        let total = 0;
        User.find(query).countDocuments().exec((err,ret) => {
            if (!err) {
                total = ret;
                let pageData = {
                    data: [],
                    total: total,
                    pageNum: page,
                    pageSize: limit
                };
                if(total == 0){
                    res.json({code: 200, msg: 'done', data: pageData});
                    return;
                }
                User.find(query).skip((page - 1)*parseInt(limit)).sort(sort).limit(parseInt(limit)).exec((err1,ret1) => {
                    if (!err1) {
                        pageData.data = ret1;
                        res.json({code: 200, msg: 'done', data: pageData});
                    }else{
                        // console.log(err1);
                        res.json({code: 500, msg: 'done'});    
                    }
                });
            }else{
                // console.log(err);
                res.json({code: 500, msg: 'done'});    
            }
        });
    },

    add (req, res) {
        const entity = new User({
            username: req.body.username,
            password: req.body.password
        });
        entity.save().then((ret) => {
            // console.log(ret);
            res.json({code: 200, msg: 'done'});
        });   
    },

    get (req, res) {
        User.findOne({
            _id: req.params.id,
        },(err,ret) => {
            if (!err) {
                console.log(ret);
                res.json({code: 200, msg: 'done', data: ret});
            }else{
                res.json({code: 500, msg: 'done'}); 
            }
        });
    },

    // 添加用户
    update (req, res) {
        User.update(
        {
            _id: req.body._id
        },{
            $set: {
                first_name: req.body.firstName,
                last_name: req.body.lastName,
                age: req.body.age,
                sex: req.body.sex,
                password: req.body.password
            }
        },(err,ret) => {
            if (!err) {
                console.log(ret);
                res.json({code: 200, msg: 'done'});
            }else{
                console.log(err);
                res.json({code: 500, msg: 'done'}); 
            }
        });
    },

    // 删除用户
    delete (req, res) {
        User.remove({
            _id: req.params.id
        },(err,ret) => {
            if (!err) {
                console.log('delete sucess!');
                res.json({code: 200, msg: 'done'});
            }else{
                res.json({code: 500, msg: 'done'}); 
            }
        });
    },

    login (req, res) {
        let username = req.body.username
        let password = req.body.password
        User.findOne({
            username: username,
        },(err,ret) => {
            if (!err) {
                // console.log(ret);
                if(ret == undefined || password != ret['password']){
                    res.json({code: 500, msg: 'account or password err'}); 
                    return;
                }
                res.json({code: 200, msg: 'done', data: ret});
            }else{
                res.json({code: 500, msg: 'done'}); 
            }
        });
    },

    reg (req, res) {
        let username = req.body.username
        let password = req.body.password
        User.findOne({
            username: username,
        },(err,ret) => {
            if (!err) {
                // console.log(ret);
                if(ret != undefined){
                    res.json({code: 500, msg: 'account alreay exist'}); 
                    return;
                }
                const entity = new User({
                    username: username,
                    password: password
                });
                entity.save().then((ret1) => {
                    // console.log(ret);
                    res.json({code: 200, msg: 'done'});
                }); 
            }else{
                res.json({code: 500, msg: 'done'}); 
            }
        });
    }
};