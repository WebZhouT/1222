let model = require('../sql/model');
let Music = model.Music

module.exports = {
    list (req, res) {
        let category = req.body.category;
        let keyword = req.body.keyword;
        let query = {}
        if(category != "" && category != undefined){
            query['category'] = category
        } 
        if(keyword != "" && keyword != undefined){
            query['musicName'] = { $regex: keyword + '.*', $options: 'i' }
        }
        console.log(query)
        Music.find(query, (err,ret) => {
            if (!err) {
                console.log(ret);
                res.json({code: 200, msg: 'done', data: ret});
                
            }else{
                console.log(err);
                res.json({code: 500, msg: 'done'});    
            }
        });
    },

    pageList (req, res) {
        let page = req.body.pageNum || 1;
        let limit = req.body.pageSize || 10;
        let sort = req.body.sort
        let category = req.body.category;
        let keyword = req.body.keyword;
        let query = {}
        if(category != "" && category != undefined){
            query['category'] = category
        }
        if(keyword != "" && keyword != undefined){
            query['musicName'] = "/" + keyword + "/"
        }
        let total = 0;
        Music.find(query).countDocuments().exec((err,ret) => {
            if (!err) {
                total = ret;
                Music.find(query).skip((page - 1)*parseInt(limit)).sort(sort).limit(parseInt(limit)).exec((err1,ret1) => {
                    if (!err1) {
                        let pageData = {
                            data: ret1,
                            total: total,
                            pageNum: page,
                            pageSize: limit
                        };
                        res.json({code: 200, msg: 'done', data: pageData});
                    }else{
                        // console.log(err1);
                        res.json({code: 500, msg: 'done'});    
                    }
                });
            }else{
                // console.log(err);
                res.json({code: 500, msg: 'done'});    
            }
        });
    },

    add (req, res) {
        const entity = new Music({
            musicName: req.body.musicName,
            category: req.body.category,
            composer: req.body.composer,
            price: req.body.price,
            description: req.body.description,
            published: req.body.published,
            newArrival: req.body.newArrival,
            url: req.body.url,
            img: req.body.img
        });
        entity.save().then((ret) => {
            // console.log(ret);
            res.json({code: 200, msg: 'done'});
        });   
    },

    get (req, res) {
        Music.findOne({
            _id: req.params.id,
        },(err,ret) => {
            if (!err) {
                console.log(ret);
                res.json({code: 200, msg: 'done', data: ret});
            }else{
                res.json({code: 500, msg: 'done'}); 
            }
        });
    },

    // 添加用户
    update (req, res) {
        Music.updateOne(
        {
            musicId: req.body.musicId
        },{
            $set: {
                musicName: req.body.musicName,
                category: req.body.category,
                composer: req.body.composer,
                price: req.body.price,
                description: req.body.description,
                published: req.body.published,
                newArrival: req.body.newArrival,
                url: req.body.url,
                img: req.body.img,
            }
        },(err,ret) => {
            if (!err) {
                // console.log(ret);
                res.json({code: 200, msg: 'done'});
            }else{
                // console.log(err);
                res.json({code: 500, msg: 'done'}); 
            }
        });
    },

    // 删除用户
    delete (req, res) {
        Music.remove({
            _id: req.params.id
        },(err,ret) => {
            if (!err) {
                // console.log('delete sucess!');
                res.json({code: 200, msg: 'done'});
            }else{
                res.json({code: 500, msg: 'done'}); 
            }
        });
    },
};