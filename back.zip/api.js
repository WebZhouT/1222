let path = '/api';

module.exports = {
    // user
    list: path + '/user/list',
    pageList: path + '/user/page/list',
    delete: path + '/user/:id',
    add: path + '/user/add',
    update: path + '/user/update',
    get: path + '/user/:id',


    login: path + '/login',
    reg: path + '/reg',

    music_list: path + '/music/list',
    music_get: path + '/music/:id',
    music_pageList: path + '/music/page/list',
    
    cart_list: path + '/cart/list',
    cart_pageList: path + '/cart/page/list',
    cart_delete: path + '/cart/delete',
    cart_add: path + '/cart/add',
};