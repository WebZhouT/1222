let func = require('./func');
const Schema = func.db.Schema;

const cartSchema = new Schema({
    musicId: {
        type: Schema.Types.ObjectId,
        ref: 'music'
    },
    username: {
        type: String
    },
    quantity: {
        type: Number
    }
})

const userSchema = new Schema({
    username: {
        type: String
    },
    password: {
        type: String
    }
})

const musicSchema = new Schema({
    musicName: {
        type: String
    },
    category: {
        type: String
    },
    composer: {
        type: String
    },
    description: {
        type: String
    },
    img: {
        type: String
    },
    url: {
        type: String
    },
    price: {
        type: String
    },
    published: {
        type: String
    },
    newArrival: {
        type: String
    }
})

module.exports = {
    Cart: func.db.model('cart', cartSchema),
    User: func.db.model('user', userSchema),
    Music: func.db.model('music', musicSchema),
};