let model = require('../sql/model');
let Music = model.Music

let musicList = [
    {
        name: 'Symphony No. 41 Jupiter, 1st Movement Allegro Vivace',
        category: 'Classic',
        composer: 'Symphony No. 41 Jupiter',
        price: '30',
        description: 'Classic Music',
        published: '1971',
        newArrival: '0'
    },
    {
        name: 'Scherzo: Allegro vivace con delicatezza',
        category: 'Classic',
        composer: 'Scherzo',
        price: '76',
        description: 'Classic Music',
        published: '1972',
        newArrival: '0'
    },
    {
        name: 'Bach, J.S.: Goldberg Variations, BWV 988',
        category: 'Classic',
        composer: 'Bach, J.S.',
        price: '10',
        description: 'Classic Music',
        published: '1971',
        newArrival: '0'
    },
    {
        name: 'Mussorgsky, Modest: Night on Bald Mountain',
        category: 'Baroque',
        composer: 'Mussorgsky, Modest',
        price: '12',
        description: 'Baroque Music',
        published: '1971',
        newArrival: '0'
    },
    {
        name: 'Claudio Monteverdi: Madrigals',
        category: 'Baroque',
        composer: 'Claudio Monteverdi',
        price: '20',
        description: 'Baroque Music',
        published: '1971',
        newArrival: '0'
    },
    {
        name: 'Bach, J.S.: Concerto No. 1 in D Major',
        category: 'Baroque',
        composer: 'Bach, J.S.',
        price: '77',
        description: 'Baroque Music',
        published: '1971',
        newArrival: '0'
    },
    {
        name: 'Frederic Chopin: Piano Concerto No. 1 in E Minor',
        category: 'Romantic',
        composer: 'Frederic Chopin',
        price: '70',
        description: 'Romantic Music',
        published: '1971',
        newArrival: '0'
    },
    {
        name: 'Franz Liszt: Christus',
        category: 'Romantic',
        composer: 'Franz Liszt',
        price: '21',
        description: 'Romantic Music',
        published: '1971',
        newArrival: '0'
    },
    {
        name: 'Claude Debussy: Childrens Corner',
        category: 'Romantic',
        composer: 'Claude Debussy',
        price: '30',
        description: 'Romantic Music',
        published: '1971',
        newArrival: '0'
    },
    {
        name: 'Robert Schumann: Papillons',
        category: 'Late 19th',
        composer: 'Robert Schumann',
        price: '18',
        description: 'Late 19th Music',
        published: '1971',
        newArrival: '0'
    },
    {
        name: 'Symphony No. 3',
        category: 'Late 19th',
        composer: 'Symphony',
        price: '40',
        description: 'Late 19th Music',
        published: '1975',
        newArrival: '1'
    },
    {
        name: 'Liszt: Bagatelle sans tonalite',
        category: 'Late 19th',
        composer: 'Liszt',
        price: '30',
        description: 'Late 19th Music',
        published: '1971',
        newArrival: '1'
    }
]
// console.log(musicList);
for(var i = 0; i < 12; i++){
    const entity = new Music({
        musicName: musicList[i].name,
        category: musicList[i].category,
        composer: musicList[i].composer,
        price: musicList[i].price,
        description: musicList[i].description,
        published: musicList[i].published,
        newArrival: musicList[i].newArrival,
        url: 'http://localhost:9999/m' + (i + 1) + '.mp3',
        img: 'http://localhost:9999/img_' + (i + 1) + '.jpg'
    });
    entity.save().then((ret) => {
        console.log(ret);
        // res.json({code: 200, msg: 'done'});
    });  
}